(function ($) {
  'use strict';

  window.FontAwesomeConfig = {
    searchPseudoElements: true
  }
})(jQuery);
